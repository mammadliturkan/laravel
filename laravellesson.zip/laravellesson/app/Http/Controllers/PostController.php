<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Category;
use App\Post;

class PostController extends Controller
{
    public function index(){
        $posts = Post::paginate(5);
        $categories = Category::all();
        return view('app', compact('posts', 'categories'));
    }

    public function show($id){
        $post = Post::find($id);
        return view('app_post', compact('post'));
    }

    public function cat($id){
        $posts = DB::table('posts')->where ('category_id',[$id])->get();
        return view('cat', compact('posts'));
    }
}
