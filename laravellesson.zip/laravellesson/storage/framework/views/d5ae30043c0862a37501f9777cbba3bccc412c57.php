
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="style/style.css">
    <title>Laravel</title>
    <style type="text/css">
        body{
            background-image: url('img/bg-1.jpg');
            background-size: cover;
            background-attachment: fixed;
        }

         .pagination .active span {
           display: inline-block;
           padding: 10px;
           padding-left: 16px;
            padding-right: 20px;
            font-size: 14px;
       }
    </style>
    <script src="jquery-3.3.1.min.js"></script>
    <script type = "text/javascript">
        $(document).ready(function() {

            $("#open").click(function(){
                document.getElementById("side").style.width = "250px";
                document.getElementById("menu").style.marginLeft = "250px";
                document.getElementById("open").style.display = "none";
            });

            $("#close").click(function(){
                document.getElementById("side").style.width = "0px";
                document.getElementById("menu").style.marginLeft = "0px";
                document.getElementById("open").style.display = "block";
            });

        });
    </script>

</head>
<body>
<div class="side" id="side">
    <a href="javascript:" id="close" class="close">&times;</a>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <a href="cat/<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div id="menu" class="menu">
    <span style="font-size: 32px; cursor: pointer;" id="open">&#9776;</span>

   <section id="home">