<?php $__env->startSection('content'); ?>

    <section id="home">
        <h1>Posts</h1>
        <div class="post">
            <a href="#">dfdkj hfehf lkleur jnjkrerh ;qwioewur</a>
        </div>

        <div class="post">
            <a href="#">dfdkj hfehf lkleur jnjkrerh ;qwioewur</a>
        </div>

        <div class="post">
            <a href="#">dfdkj hfehf lkleur jnjkrerh ;qwioewur</a>
        </div>

        <div class="post">
            <a href="#">dfdkj hfehf lkleur jnjkrerh ;qwioewur</a>
        </div>

    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>