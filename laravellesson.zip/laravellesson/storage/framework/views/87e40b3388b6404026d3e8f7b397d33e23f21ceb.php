<?php
        echo 'deneme..';
            echo '<br>';
        echo $isim;