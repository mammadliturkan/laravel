

  
         <h1 class="head"><?php echo e($post->title); ?></h1>
            <div class="blog">
                 <p><?php echo e($post->content); ?></p>
            </div>

    </section>

