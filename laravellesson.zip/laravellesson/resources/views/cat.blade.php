@extends('master')
@section('content')

    
    	@foreach($posts as $post)
         <div class="cat">
                <h1>{{ $post->title }}</h1>
                 <p>{{ $post->content }}</p>
            </div>
            @endforeach
    </section>

  @endsection