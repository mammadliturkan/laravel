@extends('master')
@section('content')

  
         <h1 class="head">{{ $post->title }}</h1>
            <div class="blog">
                 <p>{{ $post->content }}</p>
            </div>

    </section>

  @endsection