@extends('master')
@section('content')

    <section id="home">
        <h1>Posts</h1>
        <div class="post">
            <a href="#">dfdkj hfehf lkleur jnjkrerh ;qwioewur</a>
        </div>

        <div class="post">
            <a href="#">dfdkj hfehf lkleur jnjkrerh ;qwioewur</a>
        </div>

        <div class="post">
            <a href="#">dfdkj hfehf lkleur jnjkrerh ;qwioewur</a>
        </div>

        <div class="post">
            <a href="#">dfdkj hfehf lkleur jnjkrerh ;qwioewur</a>
        </div>

    </section>

    @stop