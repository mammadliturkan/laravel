@extends('master')
@section('content')

        <h1>Posts</h1>

        @foreach($posts as $post)
        <div class="post">
            <a href="blog/{{ $post->id }}">{{ $post->title }}</a>
        </div>

         @endforeach
    </section>

        {{ $posts->Links() }}

   @endsection

   



    
